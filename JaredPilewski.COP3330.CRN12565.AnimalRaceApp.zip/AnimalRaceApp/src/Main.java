/* Jared Pilewski, COP-3330C-12834
- This program creates two animals, the hare and the tortoise, who will race until one makes it to position 120
- The animals will move and sleep simultaneously, and eat one at a time
*/
public class Main {
    public static void main(String[] args) {
        Food mealTime = new Food();

        Animal hare = new Animal("Hare", 20, 150, mealTime);
        Animal tortoise = new Animal("Tortoise", 10, 50, mealTime);

        Thread hareThread = new Thread(hare);
        Thread tortoiseThread = new Thread(tortoise);

        hareThread.start();
        tortoiseThread.start();

    }
}