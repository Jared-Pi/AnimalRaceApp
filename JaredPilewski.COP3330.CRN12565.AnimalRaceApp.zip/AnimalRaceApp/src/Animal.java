import java.util.Random;
public class Animal implements Runnable {
    String name;
    int Position, restMax, distanceTraveled;
    Food food;
    static boolean winner = false;
    Random rand = new Random();

    //Constructor for making a new animal with parameters for name, speed, rest time, and eating
    public Animal(String name, int distanceTraveled, int restMax, Food food) {
        this.name = name;
        this. distanceTraveled = distanceTraveled;
        this.restMax = restMax;
        this.Position = 0;
        this.food = food;
    }

    //Run method that has each animal move, sleep, and eat until one makes it to position 120
    public void run () {
        //loops until an animal travels to 120, becoming the winner and changing the boolean to true
        while (!winner) {
            Position += distanceTraveled; //moves at the defined speed
            System.out.println(name + " moved, Position: " + Position);
            //changes boolean to true if animal travels to 120
            if (Position >= 120) {
                winner = true;
                System.out.println("Winner is: " + name + "!");
            }
            //animals won't begin eating or sleeping if running loop after winner is declared
            else {
                try {
                    int randSleep = rand.nextInt(restMax); //random number up to the defined maximum
                    System.out.println(name + " sleeps for " + randSleep);
                    Thread.sleep(randSleep);
                    food.eat(name, randSleep);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
