public class Food {
    //Animals will run the same eating method and won't be able to eat if one is already eating
    public synchronized void eat(String name, int eatTime) {
        System.out.println(name + " is eating");
        try {
            Thread.sleep(eatTime);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println(name + " is done eating");
    }
}
